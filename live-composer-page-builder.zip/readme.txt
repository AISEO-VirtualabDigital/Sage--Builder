=== Live Composer - Free WordPress Website Builder  ===
Contributors: LiveComposer
Tags: page builder, landing page builder, frontend page builder, drag and drop page builder, website builder
Requires at least: 6.0
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 2.1.20
License: GPLv3

Page builder for WordPress with drag and drop header/footer editing, responsive settings, and animations. Compatible with Gutenberg block editor.

== Description ==

https://www.youtube.com/watch?v=aVx1yGMdxKY


= Open Source WordPress Website Builder =

Join 60,000+ Others Creating with Live Composer. Unlock the Power of Open Source with Our WordPress Website Builder!
Are you looking to create stunning websites without the hassle of coding? Look no further! Our Open Source WordPress Website Builder is here to revolutionize your website creation experience.

= Why Choose Our Open Source WordPress Website Builder? =

- **Freedom:** With open-source software, you can customize and modify your website to suit your unique needs perfectly.
- **Flexibility:** Our builder offers a wide range of themes, plugins, and customization options, allowing you to effortlessly create a website that reflects your brand identity.
- **Community Support:** Join the [Github community](https://github.com/live-composer/live-composer-page-builder) of developers and users who are passionate about WordPress. Get help, share ideas, and collaborate to build excellent websites.
- **Cost-Effective:** Say goodbye to expensive website development costs. Our open-source solution is cost-effective, making professional website creation accessible to everyone.

**Key Features:**

- **User-Friendly Interface:** No coding skills? No problem! Our intuitive interface makes website building a breeze for beginners and experts alike.
- **Flexible Theme:** Build a custom website from scratch with a lightweight, fast-working theme.
- **Powerful Premium Extensions:** Enhance your website's functionality with extensions, such as Breadcrumbs, WooCommerce integration, and content restriction.
- **Mobile Responsiveness:** Ensure your website looks great on any device with built-in mobile responsiveness.
- **SEO-Friendly:** Boost your website's visibility on search engines with popular compatible SEO plugins like Rankmath, Yoast SEO, and All-in-one SEO.

Get all features with [Live Composer Premium](https://livecomposerplugin.com/)

= Drag and Drop Page Builder =

Say goodbye to coding constraints and hello to boundless creativity. With our WordPress website builder, crafting distinctive designs is effortless. Whether you're an experienced designer or just starting, our intuitive platform enables you to add and edit content precisely and efficiently. Enjoy the excitement of real-time editing, where every change appears instantly. Step into a world where your imagination has no boundaries, and unleash your creativity with our powerful builder.

= Build Powerful Sites With Premium Extensions =

Our core WordPress website builder is your gateway to limitless design possibilities and won't cost you a penny. But if you're craving that extra flair, we've covered you with a range of powerful premium extensions. Elevate your designs and take your website to the next level with our premium offerings. Why settle for the ordinary when you can get fancy?

## 📱 Mobile Responsive Page Builder

With our page builder, creating responsive websites is simple. You can customize the appearance of any page element to look perfect on all mobile devices, ensuring your site is mobile-ready.

## Multiple Language and RTL Support

Live Composer supports multiple languages and typographies, including RTL. It offers editor translations in over 63 languages and is compatible with WPML, Polylang, TranslatePress, Weglot, and more.
**Advanced, time-saving features to get your site-building skills to the next level**
Premium extensions bundle includes:
1. **[Restrict Content](https://livecomposerplugin.com/downloads/restrict-content/)**: The Restrict Content Pro plugin (premium license needed) allows you to control members' access to site areas.
2. **[Contact Forms](https://livecomposerplugin.com/downloads/contact-forms/)**: Integrate contact forms easily with drag-and-drop modules.
3. **[Preloader](https://livecomposerplugin.com/downloads/preloader-copy/)**: Customize a responsive preloader for smooth website transitions.
4. **[Video Embedding](https://livecomposerplugin.com/downloads/video//)**: Embed videos effortlessly from YouTube, Vimeo, and more.
5. **[Breadcrumbs](https://livecomposerplugin.com/downloads/breadcrumbs/)**: Enhance navigation with dynamic, clickable breadcrumbs.
6. **[ACF Support](https://livecomposerplugin.com/downloads/acf-support/)**: Display custom fields on pages, posts, or templates.
7. **[CPT Support](https://livecomposerplugin.com/downloads/cpt-support/)**: Support Custom Post Types with shared templates.
8. **[Mega Menu](https://livecomposerplugin.com/downloads/mega-menu/)**: Create customizable multicolumn and responsive menus.
9. **[3rd-Party Sliders](https://livecomposerplugin.com/downloads/sliders-integration/)**: Integrate sliders with drag-and-drop modules.
10. **[Gallery Images Grid](https://livecomposerplugin.com/downloads/gallery-images-grid/)**: Showcase images in grids or carousels.
11. **[Google Maps](https://livecomposerplugin.com/downloads/google-maps-add-on/)**: Add Google Maps with a dedicated module.
12. **[Animations](https://livecomposerplugin.com/downloads/additional-animations/)**: Add 47 new on-load animation effects.
13. **[Linecons Icons](https://livecomposerplugin.com/downloads/linecons-icons-add-on/)**: Access 48 new design icons.
14. **[Post Links](https://livecomposerplugin.com/downloads/previousnext-post-links-add-on/)**: Display previous/next post links for navigation.
15. **[Content Width](https://livecomposerplugin.com/downloads/per-page-content-width-add-on/)**: Customize content widths per page.
16. **[Before/After Slider](https://livecomposerplugin.com/downloads/beforeafter-image-slider-add-on/)**: Highlight image differences effectively.

Build your website and page using [Live Composer Premium!](https://livecomposerplugin.com/)

= Get Creative With Your WooCommerce Store =

Finally, using our drag-and-drop page builder, you can build a custom WooCommerce website from scratch. You should gradually improve your product and checkout page designs to maximize conversions. Now, you don’t need to ask a developer to make changes. Based on your analytics, improve your designs every week. Save time and money with our drag-and-drop page builder for WooCommerce.

With this premium extension, you can create the following e-commerce website pages and sections:

        - Product Page (Fully customizable)
        - Products Listings Grid (Fully customizable)
        - Checkout and Cart Pages (Fully customizable)
        - Buyer’s Account (Fully customizable)

= Master Your Online Presence with Live Composer Builder =

In the fast-moving world of online marketing, every moment counts. Live Composer is your must-have tool, offering an easy-to-use WordPress website builder made for online marketers like you. With Live Composer, you can quickly create and test eye-catching web and landing pages for your promotional campaigns, keeping you ahead in the digital game.

## Streamlined SEO Excellence

Say goodbye to the hassle of internal optimization problems. Our site builder is designed for top-notch SEO performance, creating clean, SEO-friendly code that works perfectly with popular WordPress plugins like Yoast SEO. When your clients need a cost-effective solution for their upcoming campaigns, you can be confident that you have the key to their success.

## Unleash Your Business's Visual Identity

Creating a custom website for your business has always been challenging. Forget about expensive and time-consuming projects. With our visual page composer, you can effortlessly build your company's online presence while saving time and money. Enjoy the satisfaction of designing your website from scratch, even on a tight budget.

## Freedom for Web Designers

Break free from relying on developers and HTML+CSS coders, and embrace your passion for design. Our intuitive drag-and-drop theme builder lets you easily turn your designs from Photoshop or Sketch into stunning websites. Say goodbye to PSD-to-WP coding and build beautiful websites directly in your browser. Let your creativity flow without the hassle of coding.

## Unmatched Freedom for Developers

Empower your clients with websites offering unparalleled customization options. With Live Composer, you no longer have to choose between power and simplicity. Our free base plugin provides all the framework features needed to build WordPress themes that are perfect for marketplaces. Experience the excitement of developing websites that allow users to customize their online presence to their liking.

## Effortless Portfolio Showcase

Are you looking for a quick and customizable way to display your portfolio or case studies? Our drag-and-drop portfolio builder for WordPress is the perfect solution. Easily set up your unique showcase using built-in presets that can be adjusted to create various portfolio styles. Enjoy the seamless drag-and-drop functionality you love right from the start.

## Gutenberg Compatible

Our page builder seamlessly integrates with the Gutenberg plugin, allowing you to use it alongside the new WordPress block editor without any issues.

== Frequently Asked Questions ==

= How do I activate the page builder on a page? =

When you visit a page you'll see a green "activate editor" button in the bottom right corner, click that, and the page will reload with page builder ready to use.

= What is Live Composer Page Builder? =

Live Composer Page Builder is a tool or plugin for WordPress that allows users to design and customize web pages visually without needing to write code. It employs a drag-and-drop interface for easy use.

= Why should I use Live Composer Page Builder? =

Live Composer Page Builder empowers users with limited technical skills to create professional-looking websites. It offers flexibility, customization options, and the ability to design visually appealing layouts without relying on pre-made templates.

= Is Live Composer Page Builder compatible with all WordPress themes? =

Live Composer Page Builder is compatible with a wide range of WordPress themes. However, checking compatibility before choosing the page builder is always advisable, especially if you have a specific theme in mind

= Does Live Composer Page Builder slow down my website? =

While some page builders may add additional code and scripts to your website, leading to a slight increase in load times, Live Composer Page Builder is optimized for performance. Choosing a well-coded and regularly updated page builder is essential to minimize any impact on site speed.

= Can I switch to Live Composer Page Builder without losing my content? =

Live Composer Page Builder can sometimes cause formatting issues or require reconfiguring layouts. However, Live Composer offers options to migrate content from other builders, although this may require manual adjustments.

= Is Live Composer Page Builder SEO-friendly? =

Yes, Live Composer Page Builder is designed with SEO in mind, allowing users to optimize their content for search engines. It offers customizable meta tags, heading structures, and schema markup integration.

= Do I need coding knowledge to use Live Composer Page Builder? =

No, one of the primary advantages of Live Composer Page Builder is that it caters to users who need coding skills. The drag-and-drop interface simplifies the design process, making it accessible to beginners.

= Are there free versions of Live Composer Page Builder available? =

Live Composer Page Builder offers a free version with basic functionalities for creating and customizing layouts. However, the premium version provides more advanced features and support.

= Can I create custom templates with Live Composer Page Builder? =

Yes, Live Composer Page Builder allows users to create custom templates for pages, posts, and websites. This feature enables users to maintain consistency across their site and streamline the design process.

= Is Live Composer Page Builder mobile-responsive? =

Yes, Live Composer Page Builder offers mobile responsiveness, ensuring your website looks and functions correctly on various devices, including smartphones and tablets. However, previewing and testing your designs across different screen sizes is essential to ensure optimal performance.

= What is the difference between Live Composer Page Builder's free and premium versions? =

The free version of Live Composer Page Builder offers basic features and functionalities, while the premium version provides advanced tools, templates, support, and updates. Assess your needs and budget to determine which option best suits you.

= Is Live Composer Page Builder compatible with my current WordPress theme? =

Compatibility with your WordPress theme is crucial for seamless integration and design flexibility. Before purchasing, check Live Composer's documentation or contact their support team to ensure compatibility with your theme.

= Can I customize pre-designed templates with Live Composer Page Builder? =

Yes, Live Composer Page Builder allows you to customize pre-designed templates to match your brand's aesthetic and requirements. It offers extensive customization options, including color schemes, fonts, layouts, and content modules.

= Does Live Composer Page Builder offer responsive design capabilities? =

Responsive design ensures your website looks and functions seamlessly across various devices and screen sizes. Live Composer Page Builder offers responsive design features to create mobile-friendly websites.

= Are there any limitations on how many websites or pages I can create with Live Composer Page Builder? =

Some Live Composer Page Builder versions restrict the websites or pages you can create based on your subscription plan. Review the licensing terms and limitations to ensure they align with your project requirements.

= Is customer support available for Live Composer Page Builder? =

Reliable customer support is essential for resolving technical issues and getting assistance with the page builder's features. Live Composer Page Builder offers responsive customer support through multiple channels like email, live chat, or forums.

= Does Live Composer Page Builder offer regular updates and new features? =

Regular updates ensure compatibility with the latest version of WordPress and security patches. Additionally, new features and enhancements enhance the page builder's functionality and usability over time. Live Composer Page Builder has a track record of frequent updates and feature releases.

= Can I transfer my content from another page builder to Live Composer Page Builder? =

If you're migrating from another page builder, compatibility for content transfer is essential. Live Composer Page Builder offers tools or plugins to assist with content migration, or manual transfer may be required. Consider the ease of transition before making a decision.

== Screenshots ==

1. The page builder in editing mode

== Changelog ==

⭐⭐⭐ NEW PLUGIN: STYLIST – ADDITIONAL STYLING FOR ANY SITE ELEMENT [https://wordpress.org/plugins/stylist/](https://wordpress.org/plugins/stylist/)

= DID YOU FIND A BUG IN OUR PAGE BUILDER? =
* 🐛 [Please, report any bugs on GitHub](https://github.com/livecomposer/live-composer-page-builder/issues/)
* ⌛ [You can download any previous version here](https://github.com/live-composer/live-composer-page-builder/releases)

= FOR OUR PRO USERS: =
* 🦊 [Check out our WooCommerce Page Builder Extension](https://livecomposerplugin.com/downloads/woocommerce-page-builder/?utm_source=wp-admin&utm_medium=changelog&utm_campaign=woo-integration)
* 👀 [We keep updating and improving our extensions pack](https://livecomposerplugin.com/downloads/extensions/?utm_source=wp-admin&utm_medium=changelog&utm_campaign=add-ons) ACF + CPT + MegaMenu + 9 more add-ons.

= 2.1.20 - August 24, 2026 =
* Security and vulnerability fix.

= 2.1.19 - July 30, 2026 =
* Security Fix: Prevented PHP Object Injection in module shortcode outputs.

= 2.1.18 - July 17, 2026 =
* Improved security by escaping Download module tag URLs and names.

= 2.1.17 - June 04, 2026 =
* Fix border width update issue in existing modules (Link, Button, Infobox Element Button).
* Handle image permission exceptions during project module UI rendering.

= 2.1.16 - May 12, 2026 =
* Added new module Call to action (CTA).

= 2.1.15 - May 04, 2026 =
* Fixed issues in the button module.
* Security improvement

= 2.1.14 - April 27, 2026 =
* Minor bug fixes.

= 2.1.13 - April 13, 2026 =
* Fixed carousel functionality in the Loops module.
* Fixed template part rendering in the Loops module and improved functionality.
* Minor bug fixes.
* Security improvement

= 2.1.12 - April 08, 2026 =
* Fixed an issue where special characters in Text and HTML modules prevented editing of pages and templates in the live composer
* Resolved undefined key error in the sticky row
* Fixed duplicate module area IDs caused by row duplication, preventing unintended CSS override conflicts.
* Enhanced Post and Loops modules by adding the ability to select a taxonomy for filtering.
* Updated the Meta Module to include options for choosing which taxonomy to display.
* Minor bug fixes.

= 2.1.11 - April 01, 2026 =
* Introduced individual margin and padding controls for all sides with selectable units (px, %).
* Fixed an issue where an undefined element error appeared while editing modules.
* Added support for background color and image in the modules container.
* Minor bug fixes.

= 2.1.10 - March 24, 2026 =
* Fixed an issue with editing options not displaying or hiding correctly.
* Added support for uploading and using custom images as icons in modules with buttons.

= 2.1.9 - March 20, 2026 =
* Fixed post content overwrite issue.
* Resolved an issue where certain shortcodes would return empty content due to recursive filter conflicts.
* Added protection against infinite loops when plugins or shortcodes trigger `the_content` recursively.

= 2.1.8 - March 06, 2026 =
* Minor bug fixes

= 2.1.7 - February 26, 2026 =
* Minor bug fixes

= 2.1.6 - February 25, 2026 =
* Fixed minor bugs related to show/hide functionality for specific devices in Sections, the Modules area, and individual modules.
* Resolved an issue where Module's borders were not applying correctly.
* Added a new Countdown module to display countdown timers.

= 2.1.5 - February 18 2026 =
* Fixed padding and margin design issues in module options across all modules on the editing screen..
* Resolved design issues in the Accordion Module’s editing options.
* Updated default values for the Modules Area container and fixed a bug where the border style was not applied.

= 2.1.4 - February 12 2026 =
* Added editing and responsive settings for the Module Area Container.

= 2.1.3 - February 04 2026 =
* Added a Section module for rendering custom section designs.
* Added a Link module for posts linking.
* Improved the Excerpt module: added option to show post content when no excerpt is available, with configurable word limit.
* Enhanced Loops module functionality.
* Fixed minor issues and bugs in modules.

= 2.1.2 - January 29 2026 =
* Reverted changes from Release 2.1.0

= 2.1.1 - January 29 2026 =
* Minor bug fixes

= 2.1.0 - January 28 2026 =
* Added a Section module for rendering custom section designs.
* Added a Link module for posts linking
* Improved the Excerpt module: added option to show post content when no excerpt is available, with configurable word limit.
* Fixed minor issues and bugs in modules.


= 2.0.9 - January 21 2026 =
* Fixed issues related to page design loading.
* Fixed minor UI issues in the color picker.
* Added a Loops module for rendering post loops with custom designs.
* Added support for inserting rows between existing rows.
* Reduced module and row opacity when hidden for specific device types to visually indicate responsive visibility.
* Added Undo and Redo action icons.

= 2.0.8 - January 17 2026 =
* Fixed minor issues related to padding properties in the HTML module
* Added vertical and horizontal alignment settings for containers in the Row module

= 2.0.7 - January 06 2026 =
* Fixed minor issues related to Padding properties in the HTML Module
* Fixed load page design functionality.
* Fixed an issue where top-row editing options were not visible.

= 2.0.6 - December 26 2025 =
* Fixed minor issues related to Margin and Padding properties in the Text Area Module
* Improved Undo Redo functionality

= 2.0.5 - December 20 2025 =
* Reverted changes from Release 2.0.4

= 2.0.3 - December 15 2025 =
* Security improvement
* Fixed minor bugs related to module properties
* Compatibility testing with WordPress 6.9

= 2.0.2 - December 05 2025 =
* Fixed minor issues related to Margin and Padding properties in the Module

= 2.0.1 - December 03 2025 =
* Improved Documentation

= 2.0 - November 29 2025 =

**Enhancements/Improvements**
* Relocated the modules and template list from the bottom panel to a new left sidebar for improved UI/UX.
* Added a new search feature in the left sidebar for faster module discovery.
* Enhanced the module editing workflow by introducing a popup-based module settings panel with drag-and-drop support.
 Improved duplication behavior — modules, containers, and entire rows now duplicate directly beneath the original item, ensuring a more intuitive editing flow.
* Added new Undo/Redo functionality for improved editing control.
* Introduced separate margin and padding controls for top, right, bottom, and left, with a unified unit selector (px, %).
* Added width customization options to the Row module with support for px and % units.
* Reorganized and reassigned Live Composer menu items to create a more intuitive navigation structure.
* Updated Post Title and Post Thumbnail modules with optional post-linking, allowing users to click and navigate to the associated post.
* Redesigned the container width and module width option interfaces for clearer control and improved usability.
* Fixed an issue where the CTRL + S keyboard shortcut was not triggering the save action.

= 1.5.53 - June 30 2025 =
* Updated support and documentation links.
* Compatibility with Rank Math plugin.


= 1.5.52 - Feb 28 2025 =
* Reverted changes from Release 1.5.51

= 1.5.51 - Feb 27 2025 =
* Fixed minor issues related to the content module
* Improved compatibility with WPML plugin.

= 1.5.50 - Nov 5 2024 =
* Fixed minor issues related to Margin property in Module

= 1.5.49 - October 19 2024 =
* Fixed warnings and exception handling.

= 1.5.48 - October 4 2024 =
* Fixed Depandabot security issues.

= 1.5.47 - August 22 2024 =
* Improved Documentation

= 1.5.46 - July 26 2024 =
* Improved Documentation

= 1.5.45 - July 20 2024 =
* Security fixes

= 1.5.44 - July 10 2024 =
* Security fixes

= 1.5.43 - Jun 24 2024 =
* Bug fixed: Security improvement

= 1.5.42 - Apr 29 2024 =
* Bug fixed: Background video rendering issue in iPhone

= 1.5.41 - Mar 28 2024 =
* Compatibility testing with WordPress 6.5 

= 1.5.40 - Mar 27 2024 =
* Twitter icon replaced with X

= 1.5.39 - Mar 22 2024 =
* Fixes related to Cross Site Scripting (XSS)

= 1.5.38 - Mar 15 2024 =
* Fixes related to Cross Site Request Forgery (CSRF)

= 1.5.37 - Mar 14 2024 =
* Reverted changes from Release 1.5.36

= 1.5.36 - Mar 13 2024 =
* Fixes related to Cross Site Request Forgery (CSRF)

= 1.5.35 - Feb 27 2024 =
* Security improvement

= 1.5.34 - Feb 21 2024 =
* Security improvement

= 1.5.33 - Feb 05 2024 =
* Security improvement

= 1.5.32 - Jan 25 2024 =
* Reverted changes from Release 1.5.30 and 1.5.31

= 1.5.31 - Jan 24 2024 =
* Security improvements

= 1.5.30 - Jan 24 2024 =
* Security improvements

= 1.5.29 - Jan 17 2024 =
* Security improvement

= 1.5.28 - Jan 08 2024 =
* Improved Security

= 1.5.27 - Jan 04 2024 =
* 🕷 Fix error : Resolved conflict with Yoast and Rank Math Plugins

= 1.5.26 - Jan 03 2024 =
* New feature: To provide the live composer pages, compatibility with Elementor

= 1.5.25 - Dec 18 2023 =
* Improved Security

= 1.5.24 - Dec 16 2023 =
* Tested up to WordPress 6.4.2

= 1.5.23 - Feb 28 2023 =
* Improved Security

= 1.5.22 - Oct 17 2022 =
* 🕷 Fix error : JSON Parse error Expected ',' or '}' after property value

= 1.5.21 - Aug 05 2022 =
* 🕷 Removing stylist tab
* 🕷 Thumbail not showing
* 🕷 Second time add new row issue (json issue)
* 🕷 Adding filter for license copy
* 🕷 Fix error : strftime function deprecated issue
* 🕷 Fix error : title and show_on key not found issue

= 1.5.9 - Nov 10 2020 =
* 🕷 Fix error: wpColorPickerL10n is not defined on WordPress 5.5.1

= 1.5.8 - Aug 13 2020 =
* 🕷 Fix error: mqMutationObserver is not defined

= 1.5.7 - Feb 26 2020 =
* 🕷 Disable navigating back when swiping too far in the module settings (issue #1033)
* 🕷 Editing contenteditable elements (Infobox Title, Button Title, etc.) won't cause 'Save Page' button to appear (issue #1030)

= 1.5.6 - Feb 20 2020 =
* 🕷 Fixed 'Edit Footer/Header' buttons (issue #1006)
* 🕷 Fix broken image links in project grid/carousel (issue #1024)
* 🕷 Limit errors reports only to JS warnings caused by the Live Composer
* 🔄 Update NPM packages.

= 1.5.5 - Jan 14 2020 =
* 🕷 Fixed flickering sections in the header on mobile
* 🕷 Fixed unresponsive font family selector
* 🕷 Fixed visual appearance of the license field

= 1.5.4 - Dec 10 2019 =
* 🕷 Fix bugs with Tabs and Accordions editing.

= 1.5.3 - Nov 6 2019 =
* 🆕 New feature: Copy/Paste any module styling by pressing command key.
* 🆕 New feature: Reset module responsive settings using "the trash" icon in the responsive settings panel.
* 🆕 New feature: Vertically align elements inside the module areas.
* 🕷 Minor bug fixes.
* Improved responsive settings for TEXT, IMAGE, BUTTON, and INFOBOX modules.

= 1.5.1 - Aug 9 2019 =
* 🆕 New feature: [section dividers](https://livecomposerplugin.com/section-dividers/). Flexible, [vector-based shapes](https://livecomposerplugin.com/section-dividers/) to decorate any row.
* Updated section drag and drop functionality.

= 1.4.10 - July 17 2019 =
* [4 minor bugs fixed](https://github.com/live-composer/live-composer-page-builder/issues?q=is%3Aclosed+milestone%3A1.4.10)
* [Please, report any bugs on GitHub](https://github.com/livecomposer/live-composer-page-builder/issues/)

= 1.4.9 - July 12 2019 =
* Improved compatibility with Yoast for blog posts.
* Updated icon set to the latest version of Fontawesome (1st generation).
* Major JavaScript code configuration upgrades. Now plugin uses ES6 version of Javascript. This opens a way for further plugin improvements with the latest JS libraries and frameworks.

= 1.4.7 - June 22 2019 =
* Improved compatibility with custom 3-rd party theme shortcodes.

= 1.4.6 - June 18 2019 =
* Fixed broken posts listing on the home page when WP Admin > Settings > Front Page isn't set.

= 1.4.5 - June 14 2019 =
* Code clean-up and improvements.

= 1.4.4 - May 23rd 2019 =
* 🕷 Bug: WordPress automatically create a page when defining the image title in LC.
* 🆕 New text shortcode: [dslc_bloghome] – Outputs the blog index page URL ( home_url() ).
* 🆕 New text shortcode: [dslc_archive_heading] – Heading for the archive pages.
* 🆕 New text shortcode: [nextpost_url] and [prevpost_url] –  Output an URL to the next previous post the same way as next post link works.
* 🆕 New text shortcode: [dslc_postpagination] –  Outputs single post pagination.

= 1.4.3 - May 9th 2019 =
* WordPress 5.1 is not compatible with older PHP versions anymore. If you have issues after updating WordPress or our plugin, please ask your hosting to upgrade PHP version or do it yourself via the control panel.
* Issue [#979](https://github.com/live-composer/live-composer-page-builder/issues/979): Fix php notices related to presets functionality.
* Issue [#984](https://github.com/live-composer/live-composer-page-builder/issues/984): Add "Edit In Live Composer" button into Gutenberg UI.
* Issue [#985](https://github.com/live-composer/live-composer-page-builder/issues/985): Improve Yoast compatibility with LC when using Gutenberg.
* Issue [#986](https://github.com/live-composer/live-composer-page-builder/issues/986): Recover automatic testing engine.

= 1.4.1 - January 10th 2019 =

= Bug Fixes: =
* Issue [#969](https://github.com/live-composer/live-composer-page-builder/issues/969): Module “Blog” is not filtering posts by category
* Issue [#965](https://github.com/live-composer/live-composer-page-builder/issues/965): Italics not working in WP Editor
* Issue [#972](https://github.com/live-composer/live-composer-page-builder/issues/972): Fixed bug with value in the module

= Improved: =
* Issue [#966](https://github.com/live-composer/live-composer-page-builder/issues/966): Delete Advertising Bar
